package com.edu;

import java.util.Scanner;

public class MainApp {
	
	public static void main(String[] args) {
Scanner sc=new Scanner(System.in);
		
		while(true)
		{
			System.out.println("######## DATABASE OPERATIONS ########");
			System.out.println("Enter your choice");
			System.out.println("1.Admin");
			System.out.println("2.User");
			int n= sc.nextInt(); 
			switch(n)
			{
			case 1: Admin();
			break;
			 
			case 2: User();
			break;

		    default:System.out.println("Exit");
			}
			System.out.println("Do you want to continue yes/no");
			String choice=sc.next();
			if(choice.equalsIgnoreCase("no"))
			{
				break;
			}
		}
	}		
//Getting input from Admin
	private static void Admin() {
		while(true)
		{
		
		System.out.println("1.CreateAccount");
		System.out.println("2.Search Account Detail by account number");
		System.out.println("3.DisplayCustomerAccountDetails");
		Scanner sc = new Scanner (System.in);
		int ch= sc.nextInt(); 
		switch(ch)
		{
		case 1:BankDataOperations.createAccount();
		break;
	
		case 2:BankDataOperations.SearchAccountDetail();
		break;

		case 3:BankDataOperations.DisplayCustomerDetails();
		break;

		default:System.out.println("Exit");

		}
		System.out.println("Do you want to continue yes/no");
		String c=sc.next();
		if(c.equalsIgnoreCase("no"))
		{
			break;
		}
	}
		System.out.println("Process End\n  *******");

	}
//Getting input from User
	private static void User() {
		while (true)
		{
		System.out.println("1.DepositAmount");
		System.out.println("2.WithdrawAmount ");
		System.out.println("3.CheckBalance");
		Scanner sc= new Scanner(System.in);
		int U= sc.nextInt(); 
		switch(U)
		{

		case 1:BankDataOperations.DepositAmount();
		break;

		case 2:BankDataOperations.WithdrawAmount();
		break;

		case 3:BankDataOperations.CheckBalance();
		break;
		
		default:System.out.println("exit");

		}
		System.out.println("Do you want to continue yes/no");
		String o=sc.next();
		if(o.equalsIgnoreCase("no"))
		{
			break;
		}

	}	
		System.out.println("Process End\n  *******");
	}
	
}
	
