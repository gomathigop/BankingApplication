package com.edu;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.Scanner;

public class BankDataOperations {
	static Connection scon=null;
	static ResultSet rs=null;
	static Statement st=null;

	static Scanner sc=new Scanner(System.in);
	static String Acc_no,Name,Acc_type,IFSC,Branch,Address,Phone;
	static float Deposit,Withdrawls,Balance;
//Creating Account
	public static void createAccount() { 
		try
		{
			scon=DbConnect.getConnection();
			st=scon.createStatement();
			String sql="select * from BankApp where Acc_no="+Acc_no;
			rs=st.executeQuery(sql);
			if(!rs.next()) {
				System.out.print("Enter Account No: ");  
				Acc_no = sc.next();
				System.out.print("Enter Name: "); 
				Name = sc.next();  
				System.out.print("Enter Account type: "); 
				Acc_type = sc.next();  
				System.out.print("Enter IFSC: ");  
				IFSC = sc.next();
				System.out.print("Enter Branch: ");  
				Branch = sc.next();
				System.out.print("Type Address: ");  
				Address = sc.next();
				System.out.print("Enter phone_no: ");  
				Phone = sc.next();  
				String ins="insert into BankApp values("+Acc_no+",'"+Name+"','"+Acc_type+"','"+IFSC+"','"+Branch+"','"+Address+"','"+Phone+"')";
				int i =st.executeUpdate(ins);

				if(i>0)
				{
					System.out.println("Account Created");
				}

			}else
			{
				System.out.println("Account Not Created");
			}

		}catch(Exception e)
		{
			e.printStackTrace();
		}

	}
//Amount Deposition
	public static void DepositAmount() {

		try
		{
			scon=DbConnect.getConnection();
			st=scon.createStatement();
			System.out.println("Enter Acc_no to deposit Amount");
			Acc_no=sc.next();
			System.out.println("Enter Deposit Amount");
			Deposit=sc.nextFloat();
			String ins="insert into transaction(Acc_no,Deposit,Balance) values("+Acc_no+","+Deposit+","+Balance+")";
			int i=st.executeUpdate(ins);
			String sql="update transaction set balance="+(Balance+Deposit)+" where Acc_no="+Acc_no;
			st.executeUpdate(sql);
			
			if(i>0)
			{
				System.out.println("Balance is Rs. "+Deposit);
			}
			else
			{
				System.out.println("Enter valid Acc_no");
			}
		}
			catch(Exception e)
			{
			e.printStackTrace();
			}
	}
//Amount Withdraw 
	public static void WithdrawAmount() {
		try
		{
			scon=DbConnect.getConnection();
			st=scon.createStatement();
			System.out.println("Enter Acc_no to Withdraw Amount");
			Acc_no=sc.next();
			System.out.println("Enter Withdrawl Amount");
			Withdrawls=sc.nextFloat();
			String ins="insert into transaction (Acc_no,Withdrawls,Balance) values("+Acc_no+","+Withdrawls+","+Balance+")";
			int i=st.executeUpdate(ins);
			String sql="update transaction set balance="+(Deposit-Withdrawls)+" where Acc_no="+Acc_no;
			st.executeUpdate(sql);
			if(i>0)
			{
				System.out.println("Balance is "+(Deposit-Withdrawls));
			}
			else
			{
				System.out.println("Enter valid Acc_no");
			}
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}
//Checking the Balance
	public static void CheckBalance() {
		try {
			scon=DbConnect.getConnection();
			st=scon.createStatement();
			System.out.println("Enter Acc_no to Check balance");
			Acc_no=sc.next();
			String sql="select * from Transaction where Acc_no="+Acc_no;
			rs=st.executeQuery(sql);
			if(rs.next()) {
				System.out.println("Acc_no "+rs.getLong(4)+"\nBalance Amount Rs."+rs.getFloat(3));
			}else {
				System.out.println("Enter valid Acc_no");
			}
		}catch(Exception e) {
			e.printStackTrace();
		}

	}
//Searching Account Details
	public static void SearchAccountDetail() {
		try {
			scon=DbConnect.getConnection();
			st=scon.createStatement();
			System.out.println("Enter Acc_no to display Information");
			Acc_no=sc.next();
			String sql="select * from BankApp where Acc_no="+Acc_no;
			rs=st.executeQuery(sql);
			if(rs.next()) {
				System.out.println(rs.getLong(1)+"  "+rs.getString(2)+"  "+rs.getString(3)+"  "+rs.getString(4)+"  "+rs.getString(5)+"  "+rs.getString(6)+"  "+rs.getLong(7));
			}else {
				System.out.println("Enter valid Acc_no");
			}
		}catch(Exception e) {
			e.printStackTrace();
		}

	}
//Displaying Customer Details
	public static void DisplayCustomerDetails() {
		try {
			scon=DbConnect.getConnection();
			st=scon.createStatement();
			String sql="select * from BankApp";
			rs=st.executeQuery(sql);
			System.out.println("Acc_no\t\tName\t\tAcc_type\tIFSC\t\tBranch\t\tAddress\t\tPhone");
			while(rs.next())
			{
				System.out.println(rs.getLong(1)+"\t"+rs.getString(2)+"\t\t"+rs.getString(3)+"\t\t"+rs.getString(4)+"\t"+rs.getString(5)+"\t"+rs.getString(6)+"\t"+rs.getLong(7));
			}
		}catch(Exception e) {
			e.printStackTrace();
		}

	}

}